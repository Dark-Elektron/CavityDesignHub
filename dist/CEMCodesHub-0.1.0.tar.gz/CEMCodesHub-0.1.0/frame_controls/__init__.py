# -*- coding: utf-8 -*-

__name__ = 'CavityDesignHub'
__author__ = 'Sosoho-Abasi Udongwo'
__version__ = '12.20.22'


from .plot_control import *
